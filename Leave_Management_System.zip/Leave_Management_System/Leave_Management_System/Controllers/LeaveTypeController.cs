﻿using Leave_Management_System.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveTypeController : ControllerBase
    {
        private readonly ILeaveTypeRepo leavetype;

        public LeaveTypeController(ILeaveTypeRepo leavetype)
        {
            this.leavetype = leavetype;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllTypes()
        {
            var type = await leavetype.GetAllTypes();
            return Ok(type);
        }
    }
}
