﻿using Leave_Management_System.DataBase;
using Leave_Management_System.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Repository
{
    public class LeaveTypeRepo : ILeaveTypeRepo
    {
        private readonly LMSConnect lMSConnect;

        public LeaveTypeRepo(LMSConnect lMSConnect)
        {
            this.lMSConnect = lMSConnect;
        } 
        public async  Task<List<LeaveType>> GetAllTypes()
        {
            var ar=await lMSConnect.LeaveTypes.ToListAsync();
            return ar;
            
        }

        
    }
}
